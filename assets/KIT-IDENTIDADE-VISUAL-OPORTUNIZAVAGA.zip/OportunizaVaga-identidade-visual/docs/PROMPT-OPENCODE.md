# ULTRA MEGA PROMPT — Implementar a identidade visual oficial do OportunizaVaga no OpenCode

> **Missão:** auditar o workspace aberto, configurar orientação e agentes do OpenCode de forma segura e implementar a identidade visual completa do OportunizaVaga na aplicação real. Não entregue apenas um plano, mockup ou lista de sugestões: depois da auditoria, execute a implementação por etapas, faça build/testes disponíveis e reporte o que foi realmente verificado.
>
> **Modelo recomendado:** GLM-5.3-Flash Free, se aparecer no seletor. Não fixe modelo/ID dentro das configurações do repositório; nomes e disponibilidade variam. Se o modelo estiver indisponível, continue com o modelo selecionado pelo usuário e reduza o tamanho de cada etapa.

---

## 1. Papéis e forma de trabalho

Atue como uma equipe de produto composta por:

1. **Product designer / brand designer:** garante que marca, hierarquia, cor, tipo e linguagem gráfica expressem o produto.
2. **Frontend engineer sênior:** integra tokens, logos e componentes à aplicação real sem reescrever a arquitetura.
3. **Engenheiro de acessibilidade:** valida contraste, teclado, foco, estados e reflow.
4. **QA / release engineer:** valida builds, testes, regressões e o diff.
5. **Open-source maintainer:** respeita documentação, convenções, licenças e alterações locais.

Use agentes do OpenCode quando essa instalação realmente os suportar. Se estiver disponível o recurso de subagents, delegue em paralelo apenas auditorias de leitura: auditoria da marca, acessibilidade e QA. **Não permita que vários agentes editem os mesmos arquivos em paralelo.** O agente principal coordena e é o único responsável pelo merge de mudanças. Se a versão do OpenCode não suportar alguma funcionalidade, não invente configuração: execute as revisões sequencialmente e registre a limitação.

---

## 2. Objetivo de marca

**Nome:** OportunizaVaga  
**Assinatura principal:** “Sua busca, em movimento.”  
**Conceito gráfico:** “Sinal que vira movimento.”  
**Posicionamento:** ferramenta open-source para apoiar a busca por vagas, automatizar rotinas permitidas e acompanhar candidaturas com controle, visibilidade e transparência.

A marca deve transmitir descoberta, movimento, organização e confiança. Não deve prometer emprego garantido, entrevista garantida, zero bloqueios ou suporte a todos os portais. Não use clichês de empregabilidade (maleta, pessoa com check, seta ascendente genérica) como símbolo principal.

O símbolo oficial tem um arco circular aberto, uma rota diagonal e um ponto chartreuse. O arco sugere radar/descoberta; a rota representa o caminho da informação para a ação; o ponto significa oportunidade merecedora de atenção.

### Princípios visuais

- **Azul Noturno:** `#101826` — profundidade, base e contexto técnico.
- **Cobalto:** `#3E63F5` — ação, navegação ativa, links e descoberta.
- **Chartreuse:** `#D7F36A` — ponto de sinal e acento; não usar como texto pequeno em superfícies claras nem como sucesso semântico genérico.
- **Off White:** `#F7F7F2` — fundo principal claro e texto em superfícies escuras.
- **Cinza Névoa:** `#E6EAF0` — linhas e superfícies auxiliares.
- **Coral:** `#FF725E` — atenção/intervenção pontual, não cor primária em todos os componentes.
- **Manrope:** tipografia de interface/títulos.
- **IBM Plex Mono:** logs, datas, nomes de modelo, identificadores e detalhes técnicos.
- Formas limpas, trajetos e pontos de sinal com moderação; sem blur decorativo exagerado, glassmorphism genérico, gradientes em todos os cartões ou ilustrações stock de pessoas.

O dashboard é uma ferramenta operacional: manter densidade útil. A identidade deve melhorar leitura e foco, não converter cada painel em um card colorido.

---

## 3. Contexto técnico conhecido e limites

Os pacotes analisados anteriormente indicam:

- Repositório principal `OportunizaVaga-main`, com o robô e documentação, e uma aplicação web de monitoramento em `monitor/`.
- Um segundo projeto separado chamado `monitor-main`, também com dashboard operacional. Não presuma que seja o mesmo aplicativo nem copie arquivos entre eles sem verificar.
- A implementação de monitoramento usa Next.js/React, `app/globals.css`, layouts e componentes em `components/dashboard/`; a versão do projeto pode variar.
- O CSS existente já usa tokens como `--bg`, `--surface`, `--line`, `--tx`, `--accent`, `--ok`, `--warn`, `--bad`, `--term-bg`, fontes sans/mono e `data-theme="light|dark"`. Preserve compatibilidade durante migração.
- Existe um GIF de demonstração e assets antigos de logo/favicons. Os SVGs atuais podem ser wrappers de PNG codificado em Base64; verifique o arquivo antes de decidir substituição.

**Não assuma que o workspace atual está em uma dessas pastas.** Faça a auditoria real antes de escrever.

### Restrições invioláveis

Não alterar por causa do redesign:

- motor, prompts ou loops do bot;
- adaptadores/selectors de portais e comportamento de automação;
- dados pessoais, CVs, estado de candidaturas, logs e backups;
- endpoints, contratos de API, autenticação, secrets, headers, permissões ou políticas de privacidade;
- polling, timers, cache, `localStorage`, tratamento de stale/instância fria, telemetria ou watchdog;
- scripts de deploy, workflows CI/CD ou configuração de produção, exceto se uma alteração for indispensável à importação de assets e tiver sido explicada e revisada.

Nunca abrir/apresentar arquivos com dados reais do candidato, tokens, cookies ou logs privados nos relatórios. Nunca executar automaticamente ações reais de candidatura durante os testes de UI.

---

## 4. Fase zero — reconhecer o workspace antes de editar

1. Leia `AGENTS.md`, `README`, arquivos de contribuição/segurança e a estrutura de pastas relevante.
2. Execute `git status --short` e registre mentalmente as alterações pré-existentes. **Não descarte, esconda, faça reset ou reverta alterações do usuário.**
3. Inspecione `package.json`, lockfiles e scripts reais; identifique framework, rotas, componentes, folha de estilos, sistema atual de temas, logos e favicons.
4. Localize o monitor principal. Se o workspace contiver apenas o painel secundário, adapte o escopo apenas a ele. Não mescle os dois projetos.
5. Inspecione o diff de logos existentes; determine se algum SVG é imagem Base64 em vez de vetor.
6. Antes de alterar, produza um plano curto com arquivos-alvo e risco; depois prossiga. Só interrompa para perguntar se a pasta não tiver relação com OportunizaVaga ou se uma decisão funcional irreversível for inevitável.

---

## 5. Configurar regras e agentes do OpenCode sem quebrar configuração existente

Descubra a versão instalada (`opencode --version`, se permitido) e a configuração existente. Consulte a ajuda/documentação da própria instalação se a sintaxe não for conhecida. Não fixe IDs de modelos que possam desaparecer.

Crie ou atualize por merge, nunca por substituição cega:

- `AGENTS.md`: acrescente as regras essenciais da marca e as restrições da seção 3; preserve todas as instruções existentes.
- `.opencode/agents/brand-auditor.md`: agente somente leitura que encontra uso inconsistente de cores/logos e problemas de hierarquia.
- `.opencode/agents/ui-implementer.md`: agente de implementação visual em escopo restrito, sem editar lógica de negócio.
- `.opencode/agents/accessibility-reviewer.md`: revisor somente leitura de contraste, teclado, foco, reduced motion e reflow.
- `.opencode/agents/qa-reviewer.md`: revisor somente leitura para build, testes e diff.
- `.opencode/skills/identity-system/SKILL.md`: regras reutilizáveis da identidade.

Use frontmatter/sintaxe da versão instalada de OpenCode. Se arquivos com esses nomes já existem, leia-os e faça merge conservador. Não edite `opencode.json`, `opencode.jsonc` ou arquivos globais sem necessidade clara; não mude o modelo global, chaves, permissões ou provider. Não instale plugins/dependências externas só por conveniência.

Delegação sugerida:
- `brand-auditor`: leia o código e entregue findings prioritários, sem escrever.
- `accessibility-reviewer`: após o primeiro pass de UI, revise contraste/teclado, sem escrever.
- `qa-reviewer`: após a implementação, audite diff e cobertura de teste, sem escrever.
- agente principal: planeja, implementa, resolve conflitos e executa os comandos.

Se subagents não forem suportados, execute as três revisões de modo sequencial e indique isso no relatório final.

---

## 6. Instalar os masters e documentos da marca

Crie `branding/` no repositório de destino (ou use a localização equivalente já estabelecida pela estrutura) com estes arquivos canônicos:

- `branding/tokens.json`
- `branding/tokens.css`
- `branding/manifest-assets.json`
- `branding/logos/logo-horizontal-claro.svg`
- `branding/logos/logo-horizontal-escuro.svg`
- `branding/logos/logo-empilhado.svg`
- `branding/logos/logo-monocromatico.svg`
- `branding/logos/simbolo.svg`
- `branding/icons/app-icon.svg`
- `branding/icons/favicon.svg`
- `branding/patterns/trilhas.svg`

Crie também um `branding/README.md` curto com os usos e a versão. Se o projeto já tiver localização de branding, integre sem duplicar assets concorrentes. Preserve os logos antigos fora do caminho de produção ou sob um diretório de legado com nota de migração; não apague antes de validar todos os consumidores.

Copie o conteúdo canônico dos blocos ao final deste prompt. **Não reconstrua a marca usando apenas a prancha conceitual ou emoji.** Os SVGs abaixo são os masters. Verifique que não contém `<image>`, data URI ou PNG Base64.

---

## 7. Implementar a identidade visual na aplicação real

Faça as mudanças progressivamente e dentro da arquitetura existente:

### 7.1 Tokens e tipografia

- Integre `tokens.css` à folha de estilos global usando o padrão já existente.
- Use `tokens.json` como referência de design tokens e `tokens.css` para variáveis CSS.
- Mantenha aliases compatíveis (`--brand-navy`, `--brand-blue`, `--brand-green`, `--brand-grad`, `--accent`, `--ok`, `--warn`, `--bad`, `--term-*`) se o código existente já depende deles.
- Importante: `--brand-green` deve continuar representando a semântica de sucesso para compatibilidade. Chartreuse deve viver em `--brand-lime`; não mapear chartreuse para sucesso.
- Centralize tokens; evite inserir valores hexadecimais em novos componentes.
- Use Manrope e IBM Plex Mono com fallbacks. Se as fontes forem carregadas externamente, mantenha sistema funcional quando a rede de fontes falhar.
- Tema claro e escuro devem ter contraste equivalente e sem flash visível de tema, respeitando a lógica existente de inicialização e a preferência salva.

### 7.2 Logos e ícones

- Substitua usos reais do logo antigo por `logo-horizontal-claro` ou `logo-horizontal-escuro`, conforme o fundo.
- Em espaços menores que o mínimo legível de wordmark, use o símbolo.
- Atualize favicon/manifest apenas nos pontos corretos para o framework realmente usado.
- Se a aplicação for PWA/Tauri, gere/exporte tamanhos de ícones exigidos pelo projeto; não invente pipeline de build novo sem necessidade.
- Não adicione o logo ao conteúdo de logs nem a cada cartão.

### 7.3 Aplicação e componentes

Prioridade na ordem:
1. shell, barra de estado, marca, navegação e seletor de tema;
2. hero/resumo, timestamp e estado de atualização;
3. KPI cards, lista de candidaturas e filtros;
4. área “Precisa de você”, bloqueios e pendências;
5. terminal, linha do tempo, diagnóstico, fontes, modelos e saúde;
6. menus, formulários, tabelas, popovers, empty/loading/error/stale states;
7. favicon, metadados, README e materiais de demonstração, somente quando fizer sentido.

Mantenha prioridades de informação reais. Em particular, “Precisa de você” e estado stale/erro devem ser visíveis; a informação do último heartbeat não pode ficar escondida por decoração.

### 7.4 Conteúdo e semântica

Use microcopy em português brasileiro:
- “Sua busca, em movimento.”
- “Última atualização há 4 min.” (calculada a partir dos dados reais, nunca fixa)
- “Precisa de você.”
- “Dados em cache — a fonte não confirmou uma atualização recente.” (apenas no estado correspondente)
- “Dados fictícios — demonstração.” (se e somente se for demo)
- “Ver motivo”, “Abrir log”, “Tentar novamente” quando a ação existir.

Nunca invente vagas, números, taxa de sucesso, score de compatibilidade, status ou atividade para preencher espaço. Não renomeie estados de backend se isso introduzir ambiguidade. Preserve nomes técnicos onde são necessários.

### 7.5 Sistema de interface

- Cards com raio padrão ~12 px, borda discreta e sombra baixa; não transformar todas as linhas em cards.
- Botão primário em cobalto, secundário em superfície neutra, destructive com semântica de erro.
- Chartreuse apenas em acentos de marca, ponto de destaque ou pequenas marcações de descoberta.
- Coral para intervenção/atenção com parcimônia; erros reais usam token semântico de erro.
- Logs e terminal com alto contraste, IBM Plex Mono e fundo escuro próprio em ambos os temas.
- Gráficos e estados com legenda/rótulo; nunca comunicar informação apenas por cor.
- Respeite os componentes e patterns já existentes e evite adicionar uma segunda biblioteca de UI se não for necessária.

### 7.6 Responsividade e acessibilidade

Valide larguras entre 320 e 1440 px. No celular, uma coluna predominante e sem overflow global; filtros e tabelas devem continuar operáveis. Garantir foco visível, teclado, labels acessíveis, contraste WCAG AA (4,5:1 no texto normal, 3:1 no texto grande), targets confortáveis de 40–44 px quando possível e `prefers-reduced-motion`. Botões apenas com ícone precisam de `aria-label`/nome acessível.

---

## 8. Não fazer

- Não redesenhar ou refatorar o robô de candidatura.
- Não editar payloads ou schema da API, headers secretos, tokens, segurança, autenticação, polling, cache ou persistência para “facilitar” a UI.
- Não remover métricas só porque estão difíceis de desenhar; tornar estado e limites claros.
- Não mostrar logs, nome, e-mail, currículo ou identificadores pessoais reais nas capturas de demonstração.
- Não substituir componente testado por HTML estático para satisfazer screenshot.
- Não introduzir dependência sem necessidade técnica justificada.
- Não declarar build/tests como aprovados se não os executou.
- Não deixar debug, `console.log`, CSS morto, logos duplicados ou referências a assets inexistentes.
- Não sobrescrever alterações locais; leia `git diff` antes de finalizar.

---

## 9. Plano incremental obrigatório

**Fase A — inventário e snapshot:** registrar o estado do Git, rotas, temas, tokens e assets usados; identificar scripts válidos.  
**Fase B — configuração do agente:** mesclar `AGENTS.md`, configurar agentes e skill compatíveis com a instalação, sem tocar configuração global desnecessária.  
**Fase C — assets:** criar tokens, logos vetoriais, favicon e manifest; validar sintaxe e tamanhos.  
**Fase D — tokens e shell:** migrar cores/fontes e aplicar logo, cabeçalho, navegação e temas.  
**Fase E — painéis:** aplicar estilos a KPI, listas, terminal, diagnóstico, bloqueios e restante dos componentes, preservando comportamento.  
**Fase F — responsividade e acessibilidade:** percorrer estados e breakpoints.  
**Fase G — validação:** rodar os comandos que existirem em package.json, testes, lint/build quando disponíveis; revisar o diff e rodar auditoria visual.  
**Fase H — entrega:** resumir mudanças, testes reais, riscos, pendências e como reverter apenas seus commits/alterações se necessário (sem executar reversão).

Faça commits apenas se o usuário solicitar. Não publique/deploy automaticamente.

---

## 10. Critérios objetivos de aceite

A implementação só pode ser reportada como concluída se:

- [ ] O nome e a assinatura da marca estão consistentes.
- [ ] Os assets de produção usados são SVGs vetoriais reais, sem PNG/Base64 ou links externos incorporados.
- [ ] Não existem importações quebradas nem assets com caminho inexistente.
- [ ] Tokens de marca e semânticos estão separados; chartreuse não foi convertida em cor universal de sucesso.
- [ ] Light e dark funcionam sem regressão de contraste/foco.
- [ ] O dashboard mantém os dados e suas prioridades, incluindo exceções e status stale.
- [ ] O layout funciona em 320 px, 390 px, tablet e desktop sem overflow global.
- [ ] Teclado, foco e nomes acessíveis dos botões estão preservados.
- [ ] Nenhuma lógica de bot/API/dados/segredo foi alterada como efeito colateral.
- [ ] Build/tests disponíveis foram executados ou ficaram claramente marcados como bloqueados/não executados.
- [ ] O diff foi lido e nenhuma alteração irrelevante foi introduzida.
- [ ] As limitações do teste visual são declaradas honestamente.

---

## 11. Saída final obrigatória do agente

Entregue uma resposta com:
1. resumo da identidade aplicada;
2. lista de arquivos criados e modificados por área;
3. configuração OpenCode criada/mesclada e agentes realmente suportados;
4. comandos executados e resultado literal (pass/fail/bloqueado/não executado);
5. auditoria de acessibilidade/tema/responsividade;
6. confirmação de que o bot/API/dados não foram alterados, baseada no diff;
7. pendências conhecidas e próximos passos para deploy (sem fazer deploy sem autorização).

Comece agora pela Fase A e não encerre apenas com plano. Implemente o que for seguro e verificável dentro do workspace aberto.

---

# APÊNDICE A — Tokens canônicos JSON

Crie `branding/tokens.json` com o conteúdo abaixo exatamente (não converta valores para cores aproximadas):

```json
{
  "brand": {
    "name": "OportunizaVaga",
    "version": "1.0.0",
    "concept": "Sinal que vira movimento",
    "tagline": "Sua busca, em movimento.",
    "positioning": "Busca, automação e acompanhamento de vagas com controle e transparência."
  },
  "color": {
    "brand": {
      "night": {
        "value": "#101826",
        "usage": "Base da marca, wordmark escuro e fundos profundos."
      },
      "cobalt": {
        "value": "#3E63F5",
        "usage": "Ação, navegação ativa, links e elementos de descoberta."
      },
      "chartreuse": {
        "value": "#D7F36A",
        "usage": "Ponto de sinal, destaque de descoberta e detalhe gráfico; não usar como texto pequeno em fundo claro."
      },
      "offWhite": {
        "value": "#F7F7F2",
        "usage": "Fundo claro principal e texto em fundos escuros."
      },
      "ice": {
        "value": "#E6EAF0",
        "usage": "Superfícies e divisórias suaves."
      },
      "coral": {
        "value": "#FF725E",
        "usage": "Intervenção necessária e alerta visual limitado."
      }
    },
    "light": {
      "bg": "#F7F7F2",
      "bgElev": "#EEF1F5",
      "surface": "#FFFFFF",
      "surface2": "#F7F9FC",
      "surface3": "#E9EEF5",
      "line": "#DCE2EA",
      "line2": "#C6D0DD",
      "text": "#101826",
      "textSecondary": "#4B596D",
      "textTertiary": "#68768A",
      "accent": "#3E63F5",
      "accentText": "#2F4ED0",
      "accentBg": "#E9EDFF",
      "chip": "#EEF1FF",
      "track": "#E4E9F0",
      "scroll": "#C9D2DE",
      "scrollHover": "#A8B5C5"
    },
    "dark": {
      "bg": "#0B1120",
      "bgElev": "#101826",
      "surface": "#151F30",
      "surface2": "#1B283B",
      "surface3": "#24334A",
      "line": "#29374C",
      "line2": "#3A4B64",
      "text": "#F7F7F2",
      "textSecondary": "#C0C9D7",
      "textTertiary": "#98A7BB",
      "accent": "#7890FF",
      "accentText": "#B5C2FF",
      "accentBg": "#202C50",
      "chip": "#202C50",
      "track": "#263349",
      "scroll": "#35445B",
      "scrollHover": "#50617B"
    },
    "semantic": {
      "success": {
        "light": "#167A57",
        "dark": "#50D6A0",
        "bgLight": "#E4F5EC",
        "bgDark": "#102F27"
      },
      "warning": {
        "light": "#9A5B0B",
        "dark": "#F2BB62",
        "bgLight": "#FFF2D9",
        "bgDark": "#35270F"
      },
      "danger": {
        "light": "#BD3C48",
        "dark": "#FF8B86",
        "bgLight": "#FCE8EA",
        "bgDark": "#381A22"
      },
      "info": {
        "light": "#2F55C7",
        "dark": "#91A9FF",
        "bgLight": "#E9EDFF",
        "bgDark": "#1A284D"
      }
    }
  },
  "typography": {
    "sans": {
      "family": "Manrope",
      "weights": [
        400,
        500,
        600,
        700,
        800
      ],
      "fallback": "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif"
    },
    "mono": {
      "family": "IBM Plex Mono",
      "weights": [
        400,
        500,
        600
      ],
      "fallback": "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace"
    },
    "scale": {
      "display": {
        "size": "clamp(2rem, 4vw, 3.25rem)",
        "weight": 800,
        "lineHeight": 1.05,
        "tracking": "-0.045em"
      },
      "h1": {
        "size": "2rem",
        "weight": 800,
        "lineHeight": 1.15,
        "tracking": "-0.035em"
      },
      "h2": {
        "size": "1.5rem",
        "weight": 750,
        "lineHeight": 1.2,
        "tracking": "-0.025em"
      },
      "h3": {
        "size": "1.125rem",
        "weight": 700,
        "lineHeight": 1.3,
        "tracking": "-0.015em"
      },
      "body": {
        "size": "0.9375rem",
        "weight": 400,
        "lineHeight": 1.6
      },
      "small": {
        "size": "0.8125rem",
        "weight": 400,
        "lineHeight": 1.5
      },
      "micro": {
        "size": "0.6875rem",
        "weight": 500,
        "lineHeight": 1.4
      }
    }
  },
  "spacing": {
    "unit": 4,
    "scale": {
      "1": "4px",
      "2": "8px",
      "3": "12px",
      "4": "16px",
      "5": "20px",
      "6": "24px",
      "8": "32px",
      "10": "40px",
      "12": "48px",
      "16": "64px",
      "20": "80px"
    }
  },
  "radius": {
    "xs": "5px",
    "sm": "8px",
    "md": "12px",
    "lg": "16px",
    "xl": "22px",
    "pill": "999px"
  },
  "shadow": {
    "card": "0 1px 2px rgba(16,24,38,.04), 0 8px 24px rgba(16,24,38,.035)",
    "popover": "0 16px 48px rgba(16,24,38,.18)"
  },
  "motion": {
    "fast": "120ms",
    "normal": "180ms",
    "slow": "280ms",
    "easing": "cubic-bezier(.2,.75,.25,1)",
    "reduceMotion": "Respect prefers-reduced-motion; disable nonessential movement."
  },
  "layout": {
    "maxWidth": "1280px",
    "desktopGutter": "32px",
    "tabletGutter": "24px",
    "mobileGutter": "16px",
    "stripHeight": "60px",
    "panelGap": "16px"
  },
  "accessibility": {
    "bodyTextContrast": "At least 4.5:1 for normal text",
    "largeTextContrast": "At least 3:1",
    "focus": "Visible 2px focus indicator plus 2px offset",
    "status": "Never convey status by color alone; include label/icon/text",
    "target": "Aim for 40-44px interactive height; never below WCAG target requirements without exception"
  }
}
```

# APÊNDICE B — CSS tokens canônicos

Crie `branding/tokens.css` com o conteúdo abaixo, mantendo os aliases de compatibilidade:

```css
/* OportunizaVaga Design Tokens v1.0.0
   Canonical source: branding/tokens.json
   Compatibility aliases retain existing monitor/app/globals.css selectors.
*/
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Manrope:wght@400;500;600;700;800&display=swap');

:root,
[data-theme="light"] {
  color-scheme: light;
  --font-sans: "Manrope", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  --font-mono: "IBM Plex Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;

  /* Brand */
  --brand-ink: #101826;
  --brand-navy: #101826;
  --brand-cobalt: #3E63F5;
  --brand-blue: #3E63F5;
  --brand-lime: #D7F36A;
  --brand-coral: #FF725E;
  --brand-offwhite: #F7F7F2;
  --brand-ice: #E6EAF0;
  --brand-green: #167A57; /* compatibility alias: semantic success, not brand lime */
  --brand-grad: linear-gradient(110deg, #3E63F5 0%, #5875FF 100%);

  /* Light surfaces */
  --bg: #F7F7F2;
  --bg-elev: #EEF1F5;
  --surface: #FFFFFF;
  --surface-2: #F7F9FC;
  --surface-3: #E9EEF5;
  --line: #DCE2EA;
  --line-2: #C6D0DD;
  --tx: #101826;
  --tx2: #4B596D;
  --tx3: #68768A;
  --ink: #101826;
  --ink-inv: #FFFFFF;
  --track: #E4E9F0;
  --scroll: #C9D2DE;
  --scroll-hover: #A8B5C5;

  /* Interaction */
  --accent: #3E63F5;
  --accent-tx: #2F4ED0;
  --accent-bg: #E9EDFF;
  --chip: #EEF1FF;
  --ring: 0 0 0 3px rgba(62, 99, 245, .24);

  /* Semantic states: never rely on color alone */
  --ok: #167A57; --ok-bg: #E4F5EC; --ok-dot: #167A57;
  --warn: #9A5B0B; --warn-bg: #FFF2D9;
  --bad: #BD3C48; --bad-bg: #FCE8EA;
  --info: #2F55C7; --info-bg: #E9EDFF;

  /* Terminal stays dark in either theme */
  --term-bg: #0B1120;
  --term-line: #26354D;
  --term-tx: #D7E0EF;
  --term-dim: #98A7BB;
  --term-hi: #F7F7F2;
  --term-ok: #50D6A0;
  --term-warn: #F2BB62;
  --term-bad: #FF8B86;

  /* Shape, elevation, movement */
  --radius: 12px;
  --radius-sm: 8px;
  --radius-xs: 5px;
  --shadow: 0 1px 2px rgba(16, 24, 38, .04), 0 8px 24px rgba(16, 24, 38, .035);
  --shadow-pop: 0 16px 48px rgba(16, 24, 38, .18);
  --strip-h: 60px;
  --pulse-c: #3E63F5;
}

[data-theme="dark"] {
  color-scheme: dark;
  --bg: #0B1120;
  --bg-elev: #101826;
  --surface: #151F30;
  --surface-2: #1B283B;
  --surface-3: #24334A;
  --line: #29374C;
  --line-2: #3A4B64;
  --tx: #F7F7F2;
  --tx2: #C0C9D7;
  --tx3: #98A7BB;
  --ink: #F7F7F2;
  --ink-inv: #101826;
  --track: #263349;
  --scroll: #35445B;
  --scroll-hover: #50617B;
  --accent: #7890FF;
  --accent-tx: #B5C2FF;
  --accent-bg: #202C50;
  --chip: #202C50;
  --ring: 0 0 0 3px rgba(120, 144, 255, .32);
  --ok: #50D6A0; --ok-bg: #102F27; --ok-dot: #50D6A0;
  --warn: #F2BB62; --warn-bg: #35270F;
  --bad: #FF8B86; --bad-bg: #381A22;
  --info: #91A9FF; --info-bg: #1A284D;
  --shadow: 0 1px 2px rgba(0, 0, 0, .32);
  --shadow-pop: 0 16px 48px rgba(0, 0, 0, .42);
  --term-bg: #070C17;
  --term-line: #202F49;
  --term-tx: #D7E0EF;
  --term-dim: #8D9EB8;
  --term-hi: #F7F7F2;
  --term-ok: #50D6A0;
  --term-warn: #F2BB62;
  --term-bad: #FF8B86;
  --pulse-c: #7890FF;
}

/* New semantic aliases for components gradually migrated to semantic naming. */
:root { --color-brand-ink: var(--brand-ink); --color-brand-primary: var(--brand-cobalt); --color-brand-highlight: var(--brand-lime); --color-brand-alert: var(--brand-coral); }
```

# APÊNDICE C — Manifesto canônico de assets

Crie `branding/manifest-assets.json`:

```json
{
  "schemaVersion": "1.0.0",
  "brand": "OportunizaVaga",
  "notes": "SVGs are canonical vector assets. The concept board is an art-direction reference and is not the source of truth for exact copy or geometry.",
  "assets": [
    {
      "path": "branding/logos/logo-horizontal-claro.svg",
      "type": "logo",
      "format": "SVG",
      "background": "light",
      "use": "Header, documentation, product marketing on light surfaces"
    },
    {
      "path": "branding/logos/logo-horizontal-escuro.svg",
      "type": "logo",
      "format": "SVG",
      "background": "dark",
      "use": "Header, README hero, product marketing on dark surfaces"
    },
    {
      "path": "branding/logos/logo-empilhado.svg",
      "type": "logo",
      "format": "SVG",
      "background": "light",
      "use": "Square-ish layouts, cover page and social cards"
    },
    {
      "path": "branding/logos/logo-monocromatico.svg",
      "type": "logo",
      "format": "SVG",
      "background": "light",
      "use": "Printing, constrained one-color contexts"
    },
    {
      "path": "branding/logos/simbolo.svg",
      "type": "symbol",
      "format": "SVG",
      "background": "transparent",
      "use": "Small mark, avatars, navigation if contrast is adequate"
    },
    {
      "path": "branding/icons/app-icon.svg",
      "type": "application-icon",
      "format": "SVG",
      "background": "dark",
      "use": "Desktop/mobile app icon; derive raster sizes from this source"
    },
    {
      "path": "branding/icons/favicon.svg",
      "type": "favicon",
      "format": "SVG",
      "background": "dark",
      "use": "Website and dashboard favicon"
    },
    {
      "path": "branding/patterns/trilhas.svg",
      "type": "pattern",
      "format": "SVG",
      "background": "transparent",
      "use": "Subtle editorial backdrops, banners and README imagery; never behind dense data tables"
    },
    {
      "path": "branding/reference/prancha-conceitual.png",
      "type": "moodboard",
      "format": "PNG",
      "background": "mixed",
      "use": "Art-direction inspiration only; not a canonical logo master"
    },
    {
      "path": "branding/tokens.json",
      "type": "design-tokens",
      "format": "JSON",
      "use": "Canonical machine-readable token definitions"
    },
    {
      "path": "branding/tokens.css",
      "type": "design-tokens",
      "format": "CSS",
      "use": "CSS custom properties and compatibility aliases for existing dashboard styles"
    },
    {
      "path": "branding/icons/app-icon-512.png",
      "type": "application-icon-export",
      "format": "PNG",
      "background": "dark",
      "use": "Raster export 512x512 for platforms that require PNG; SVG remains canonical"
    },
    {
      "path": "branding/icons/app-icon-192.png",
      "type": "application-icon-export",
      "format": "PNG",
      "background": "dark",
      "use": "Raster export 192x192"
    },
    {
      "path": "branding/icons/favicon-32.png",
      "type": "favicon-export",
      "format": "PNG",
      "background": "dark",
      "use": "Raster fallback for hosting systems that require PNG"
    },
    {
      "path": "branding/logos/logo-horizontal-claro.png",
      "type": "logo-export",
      "format": "PNG",
      "background": "transparent",
      "use": "Raster convenience export; SVG remains canonical"
    },
    {
      "path": "branding/logos/logo-horizontal-escuro.png",
      "type": "logo-export",
      "format": "PNG",
      "background": "transparent",
      "use": "Raster convenience export; SVG remains canonical"
    },
    {
      "path": "branding/social/og-banner.svg",
      "type": "social-preview",
      "format": "SVG",
      "background": "dark",
      "use": "Open Graph / GitHub social preview source"
    },
    {
      "path": "branding/social/og-banner.png",
      "type": "social-preview",
      "format": "PNG",
      "background": "dark",
      "use": "1200×630 raster cover for social preview and repository presentation"
    }
  ]
}
```

# APÊNDICE D — Masters SVG canônicos

Crie os SVGs abaixo nos caminhos especificados. Preservar o conteúdo e não embutir fontes bitmap:


## `logos/logo-horizontal-claro.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="690" height="108" viewBox="0 0 690 108" role="img" aria-labelledby="title desc">
<title id="title">OportunizaVaga</title><desc id="desc">Logotipo horizontal OportunizaVaga com símbolo de sinal e rota.</desc>
<g transform="translate(4 18) scale(1.14)"><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></g>
<text x="91" y="57" font-family="Manrope, Arial, sans-serif" font-size="43" font-weight="800" letter-spacing="-1.8" fill="#101826">Oportuniza<tspan fill="#3E63F5">Vaga</tspan></text>
<text x="93" y="83" font-family="Manrope, Arial, sans-serif" font-size="10.5" font-weight="700" letter-spacing="3.1" fill="#596577">SUA BUSCA, EM MOVIMENTO.</text>
</svg>
```

## `logos/logo-horizontal-escuro.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="690" height="108" viewBox="0 0 690 108" role="img" aria-labelledby="title desc">
<title id="title">OportunizaVaga</title><desc id="desc">Logotipo horizontal OportunizaVaga com símbolo de sinal e rota.</desc>
<g transform="translate(4 18) scale(1.14)"><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></g>
<text x="91" y="57" font-family="Manrope, Arial, sans-serif" font-size="43" font-weight="800" letter-spacing="-1.8" fill="#F7F7F2">Oportuniza<tspan fill="#3E63F5">Vaga</tspan></text>
<text x="93" y="83" font-family="Manrope, Arial, sans-serif" font-size="10.5" font-weight="700" letter-spacing="3.1" fill="#D7F36A">SUA BUSCA, EM MOVIMENTO.</text>
</svg>
```

## `logos/logo-empilhado.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="360" height="250" viewBox="0 0 360 250" role="img" aria-labelledby="title desc"><title id="title">OportunizaVaga</title><desc id="desc">Logotipo empilhado.</desc><g transform="translate(139 10) scale(1.3)"><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></g><text x="180" y="135" text-anchor="middle" font-family="Manrope, Arial, sans-serif" font-size="33" font-weight="800" letter-spacing="-1.2" fill="#101826">Oportuniza<tspan fill="#3E63F5">Vaga</tspan></text><text x="180" y="162" text-anchor="middle" font-family="Manrope, Arial, sans-serif" font-size="9.5" font-weight="700" letter-spacing="2.2" fill="#596577">SUA BUSCA, EM MOVIMENTO.</text></svg>
```

## `logos/logo-monocromatico.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="690" height="108" viewBox="0 0 690 108" role="img" aria-labelledby="title"><title id="title">OportunizaVaga — versão monocromática</title><g transform="translate(4 18) scale(1.14)"><g fill="none" stroke="#101826" stroke-linecap="round" stroke-linejoin="round"><path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke-width="8.5"/><path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke-width="6.7"/><path d="M 18.8 44.8 L 32.9 30.7" stroke-width="6.8"/><circle cx="35.4" cy="28.2" r="5.8" fill="#101826" stroke="none"/></g></g><text x="91" y="57" font-family="Manrope, Arial, sans-serif" font-size="43" font-weight="800" letter-spacing="-1.8" fill="#101826">OportunizaVaga</text><text x="93" y="83" font-family="Manrope, Arial, sans-serif" font-size="10.5" font-weight="700" letter-spacing="3.1" fill="#101826">SUA BUSCA, EM MOVIMENTO.</text></svg>
```

## `logos/simbolo.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64" role="img" aria-labelledby="title desc"><title id="title">Símbolo OportunizaVaga</title><desc id="desc">Um sinal circular aberto em azul com uma rota e um ponto chartreuse.</desc><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></svg>
```

## `icons/app-icon.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512" role="img" aria-labelledby="title desc"><title id="title">OportunizaVaga — ícone do aplicativo</title><desc id="desc">Símbolo de oportunidade e movimento sobre azul noturno.</desc><rect width="512" height="512" rx="112" fill="#101826"/><g transform="translate(88 88) scale(5.25)"><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></g></svg>
```

## `icons/favicon.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64" role="img" aria-labelledby="title"><title id="title">OportunizaVaga</title><rect width="64" height="64" rx="15" fill="#101826"/><g fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M 46.5 13.6 A 26.8 26.8 0 1 0 52.8 39.2" stroke="#3E63F5" stroke-width="8.5"/>
  <path d="M 41.9 16.8 L 50.9 10.4 L 53.0 21.4" stroke="#D7F36A" stroke-width="6.7"/>
  <path d="M 18.8 44.8 L 32.9 30.7" stroke="#D7F36A" stroke-width="6.8"/>
  <circle cx="35.4" cy="28.2" r="5.8" fill="#D7F36A" stroke="none"/>
</g></svg>
```

## `patterns/trilhas.svg`

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="640" height="320" viewBox="0 0 640 320"><rect width="640" height="320" fill="none"/><g fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M-20 260 C80 260 72 206 154 206 S220 246 292 246 360 120 438 120 520 156 660 36" stroke="#3E63F5" opacity=".9"/><path d="M-20 292 C84 292 104 240 168 240 S250 278 320 278 390 158 454 158 550 194 660 72" stroke="#D7F36A" opacity=".85"/><path d="M-20 228 C60 228 90 168 142 168 S228 206 286 206 358 90 420 90 535 120 660 4" stroke="#7E93FF" opacity=".7"/></g><g fill="#D7F36A"><circle cx="154" cy="206" r="5"/><circle cx="320" cy="278" r="5"/><circle cx="454" cy="158" r="5"/></g><g fill="#3E63F5"><circle cx="292" cy="246" r="4"/><circle cx="438" cy="120" r="4"/><circle cx="142" cy="168" r="4"/></g></svg>
```


# APÊNDICE E — Agentes e skill sugeridos

Se a versão instalada aceitar subagents e skills nesse formato, crie estes arquivos com base no conteúdo abaixo, mesclando se já existirem:

## `.opencode/agents/brand-auditor.md`

```markdown
---
description: Audita consistência de marca, logos, tokens e uso visual do OportunizaVaga sem editar arquivos.
mode: subagent
---
Você é o revisor de identidade visual do OportunizaVaga. Leia os documentos de marca disponíveis. Compare o código e os assets com `branding/tokens.json`, `branding/tokens.css`, os SVGs canônicos e as regras de marca. Identifique: hexadecimais hardcoded, logos rasterizados/duplicados, uso de cores semânticas incorretas, componentes inconsistentes, gradientes excessivos, acessibilidade e regressões visuais. Não edite arquivos nem recomende mudanças de lógica do robô. Entregue findings priorizados por severidade com caminho, seletor/componente e correção mínima.
```

## `.opencode/agents/ui-implementer.md`

```markdown
---
description: Implementa a identidade visual em componentes web existentes preservando comportamento e arquitetura.
mode: subagent
---
Implemente apenas mudanças de apresentação no escopo que o agente principal designar. Leia tokens e sistema de design antes de editar. Reutilize componentes e CSS existentes; evite reescrever a aplicação, duplicar tokens ou alterar APIs, endpoints, estado, polling, persistência, bot, adaptadores de sites, permissões, automação de candidatura ou lógica de dados. Preserve alterações do usuário. Não sobrescreva arquivos de agentes/configuração sem merge. Ao concluir, liste arquivos alterados e comandos/testes executados com resultados reais.
```

## `.opencode/agents/accessibility-reviewer.md`

```markdown
---
description: Revisa contraste, teclado, foco, semântica, temas e responsividade após mudanças de UI.
mode: subagent
---
Revise a interface sem modificá-la. Verifique WCAG AA para contraste de texto, foco visível, labels acessíveis, botões de ícone, mensagens de status que não dependem somente de cor, `prefers-reduced-motion`, comportamento em largura 320–390 px, zoom/reflow e paridade entre light/dark. Liste apenas findings verificáveis com caminho/componente e passos de reprodução. Não classifique uma tela como acessível sem conferir os detalhes.
```

## `.opencode/agents/qa-reviewer.md`

```markdown
---
description: Confere build, testes, regressões funcionais e integridade do diff da mudança visual.
mode: subagent
---
Audite a mudança final como revisor QA. Descubra os comandos válidos lendo `package.json`, lockfiles e documentação; não invente comandos. Execute ou peça ao agente principal para executar build/test/lint disponíveis. Revise o diff à procura de mudanças acidentais em APIs, polling, localStorage, dados, segredos, scripts de automação e configurações. Reporte separadamente testes executados, não executados e bloqueios ambientais. Não edite arquivos.
```

## `.opencode/skills/identity-system/SKILL.md`

```markdown
---
name: identity-system
description: Regras oficiais da identidade visual do OportunizaVaga para implementação, expansão de telas e auditoria.
license: MIT
compatibility: OpenCode
---

# OportunizaVaga — identidade visual

Antes de implementar uma nova tela ou alterar componentes:

1. Leia `branding/tokens.json`, `branding/tokens.css`, `branding/manifest-assets.json`, `docs/GUIA-DE-MARCA.md` e `docs/SISTEMA-DE-DESIGN.md` (ou os locais equivalentes se integrados em outro diretório).
2. Use Manrope para UI e IBM Plex Mono para dados técnicos, logs e timestamps; mantenha fallback local de sistema.
3. Use Azul Noturno `#101826`, Cobalto `#3E63F5`, Chartreuse `#D7F36A`, Off White `#F7F7F2`, Cinza Névoa `#E6EAF0` e Coral `#FF725E` conforme os usos definidos. Não misture chartreuse de marca com sucesso semântico.
4. Consuma CSS variables; não replique códigos hexadecimais em cada componente.
5. Use o logo vetorial correto para fundos claros/escuros. O símbolo isolado é para tamanhos pequenos. Nunca crie SVG com PNG em Base64.
6. Toda informação de estado deve combinar rótulo textual e, quando útil, ícone; cor é redundante.
7. Preserve paridade entre light/dark, foco, teclado, reduced motion e reflow mobile.
8. Não mude o motor de candidaturas, fontes, dados, APIs, lógica de estado, polling, persistência, autenticação, bot, scripts ou proteções por conta de um redesign.
9. Diferencie dados reais, demos, cache, stale, erros, bloqueios e estados não confirmados. Não fabrique métricas.
10. Valide build/testes existentes e revise o diff; não declare sucesso de testes que não foram executados.
```

## Addendum para `AGENTS.md`

```markdown
# Addendum de agentes — identidade visual OportunizaVaga

Mescle estas regras ao `AGENTS.md` existente; não substitua instruções já presentes.

- A marca é “OportunizaVaga”; assinatura: “Sua busca, em movimento.”
- Fonte canônica: `branding/tokens.json`, `branding/tokens.css`, `branding/manifest-assets.json`, `branding/logos/`, `branding/icons/` e `docs/GUIA-DE-MARCA.md`.
- Antes de mexer, inspecione `git status`, estrutura do repositório, scripts disponíveis e arquitetura do monitor. Preserve alterações locais não relacionadas.
- Trate `OportunizaVaga-main/monitor/` e o `monitor-main` separado como projetos potencialmente distintos. Não os mescle automaticamente.
- Redesign é de apresentação. Não altere lógica do bot, adaptadores de portais, fluxo de candidaturas, APIs, polling, persistência, secrets, autenticação, ou regras de privacidade/consentimento.
- Faça mudanças incrementais, valide build/testes e inspecione o diff.
- Não afirme que todos os portais, candidaturas ou APIs funcionam só porque o dashboard tem uma aparência mais polida.
```

