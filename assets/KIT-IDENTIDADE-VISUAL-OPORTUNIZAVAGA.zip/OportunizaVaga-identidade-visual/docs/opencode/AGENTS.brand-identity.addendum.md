# Addendum de agentes — identidade visual OportunizaVaga

Mescle estas regras ao `AGENTS.md` existente; não substitua instruções já presentes.

- A marca é “OportunizaVaga”; assinatura: “Sua busca, em movimento.”
- Fonte canônica: `branding/tokens.json`, `branding/tokens.css`, `branding/manifest-assets.json`, `branding/logos/`, `branding/icons/` e `docs/GUIA-DE-MARCA.md`.
- Antes de mexer, inspecione `git status`, estrutura do repositório, scripts disponíveis e arquitetura do monitor. Preserve alterações locais não relacionadas.
- Trate `OportunizaVaga-main/monitor/` e o `monitor-main` separado como projetos potencialmente distintos. Não os mescle automaticamente.
- Redesign é de apresentação. Não altere lógica do bot, adaptadores de portais, fluxo de candidaturas, APIs, polling, persistência, secrets, autenticação, ou regras de privacidade/consentimento.
- Faça mudanças incrementais, valide build/testes e inspecione o diff.
- Não afirme que todos os portais, candidaturas ou APIs funcionam só porque o dashboard tem uma aparência mais polida.
