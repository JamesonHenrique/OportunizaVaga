# OportunizaVaga — Kit de Identidade Visual v1.0.0

Este kit formaliza uma nova direção visual para OportunizaVaga, criada a partir da inspeção do código e dos assets fornecidos. É um pacote de marca e handoff — não altera automaticamente o código das duas aplicações fornecidas.

## Direção da marca

**Posicionamento:** ferramenta aberta para apoiar a busca por vagas, automatizar rotinas permitidas e acompanhar candidaturas com controle e transparência.

**Assinatura:** “Sua busca, em movimento.”

**Conceito visual:** “Sinal que vira movimento” — símbolo circular aberto, rota diagonal e ponto de destaque. O círculo comunica radar/descoberta; a rota comunica fluxo; o ponto chartreuse representa a oportunidade encontrada.

## Começar

1. Leia `docs/AUDITORIA-MARCA-ATUAL.md`.
2. Leia `docs/GUIA-DE-MARCA.md` e `docs/SISTEMA-DE-DESIGN.md`.
3. Copie `branding/` para o repositório de destino.
4. Leia e cole/executa o `docs/PROMPT-OPENCODE.md` no OpenCode para implementar a identidade no código real.
5. Faça build e revisão visual no app antes de publicar.

## Estrutura

- `branding/logos/`: assinaturas em SVG real, sem bitmap embutido.
- `branding/icons/`: ícone do app e favicon.
- `branding/patterns/`: elemento gráfico de trilha/rota.
- `branding/reference/prancha-conceitual.png`: moodboard; serve como inspiração e não substitui os masters vetoriais.
- `branding/tokens.json`: fonte canônica dos tokens.
- `branding/tokens.css`: CSS custom properties com aliases para as variáveis já usadas no dashboard.
- `branding/manifest-assets.json`: inventário dos arquivos.
- `docs/opencode/`: instruções e agentes auxiliares para auditoria, implementação e verificação.

## Importante

O kit é uma proposta consistente para revisão e implementação. As versões vetoriais são masters novos. Antes de trocar assets, preserve os arquivos atuais e compare telas reais em light e dark mode. A prancha conceitual gerada não é uma especificação pixel-perfect; para implementação, prevalecem SVG, tokens e documentação.
